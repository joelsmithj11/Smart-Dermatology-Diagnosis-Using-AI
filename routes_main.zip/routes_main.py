from flask import Blueprint, render_template, request, redirect, url_for, flash, send_from_directory, current_app
from flask_login import login_required, current_user
import os
import numpy as np
from datetime import datetime
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from app.utils.db import get_connection
# Gradient CAM import might need adjustment based on where it is. 
# Assuming I moved it to app.utils.gradcam
# But wait, gradcam.py might rely on other things. I will check imports inside gradcam.py if it fails.
from app.utils.gradcam import make_gradcam_heatmap, save_and_overlay_gradcam
from fpdf import FPDF
import uuid
from app.utils.report_gen import ReportGenerator

main_bp = Blueprint('main', __name__)

from tensorflow.keras.layers import DepthwiseConv2D

class FixedDepthwiseConv2D(DepthwiseConv2D):
    def __init__(self, **kwargs):
        if 'groups' in kwargs:
            kwargs.pop('groups')
        super().__init__(**kwargs)

# Load model once at startup (or lazy load)
# Load model once at startup (or lazy load)
MODEL_SAVE_PATH = "model/skin_disease_model.h5"
# Load model once at startup (or lazy load)
MODEL_PATH = "model/skin_disease_model_v4_balanced.h5"
try:
    model = load_model("model/skin_disease_model_v4_balanced.h5")
except Exception as e:
    print(f"Warning: Could not load model from {MODEL_PATH}")
    print(e)
    model = None

# Import disease information for 23-class dataset
from app.disease_info import LABELS, DESCRIPTIONS, FIRST_AID

def get_severity(conf):
    if conf >= 85: return "High Risk"
    elif conf >= 60: return "Moderate Risk"
    return "Low Risk"

@main_bp.route('/set_language/<lang>')
def set_language(lang):
    from flask import session
    session['lang'] = lang
    return redirect(request.referrer or url_for('main.index'))

@main_bp.route('/')
def index():
    return render_template('index.html')

@main_bp.route('/home')
@login_required
def home():
    return render_template('user/home.html')

@main_bp.route('/diagnose', methods=['GET', 'POST'])
@login_required
def diagnose():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        
        if file and model:
            # Save file
            filename = str(uuid.uuid4()) + ".jpg" # enforce jpg for consistency or keep extension
            upload_path = os.path.join(current_app.root_path, 'static', 'uploads', filename)
            file.save(upload_path)
            
            # Preprocess
            img = image.load_img(upload_path, target_size=(224, 224))
            arr = image.img_to_array(img)
            arr = np.expand_dims(arr, axis=0)
            arr = preprocess_input(arr)
            
            # Predict
            preds = model.predict(arr)
            idx = np.argmax(preds)
            disease_pre = LABELS[idx]
            confidence = float(preds[0][idx] * 100)
            
            # 1. Check for Unknown_Normal (Healthy/Normal Skin)
            if disease_pre == "Unknown_Normal":
                disease = "No Disease Found"
                severity = "Normal"
                confidence = float(preds[0][idx] * 100) # Show actual confidence
                desc = DESCRIPTION.get("Unknown_Normal")
                first_aid = FIRST_AID.get("Unknown_Normal")

            # 2. Check for Low Confidence (Out of Distribution / Unknown Disease)
            # Threshold lowered to 30% because model accuracy is currently ~43%.
            # 36% is a significant signal compared to random (~4.5%).
            elif confidence < 20.0:
                disease = "No Match Found"
                severity = "Uncertain"
                desc = "The uploaded image does not match any skin condition in our training dataset with sufficient confidence."
                first_aid = "Please consult a certified dermatologist for a proper diagnosis."
            else:
                # Valid Match - General confidence threshold
                disease = disease_pre
                if confidence > 85:
                    severity = "High Confidence"
                elif confidence > 60:
                    severity = "Moderate Risk"
                else:
                    severity = "Low Confidence Match"
                    
                desc = DESCRIPTIONS.get(disease, "No description available.")
                first_aid = FIRST_AID.get(disease, "Consult a doctor.")
            
            # GradCAM
            heatmap = make_gradcam_heatmap(arr, model, "Conv_1")
            
            # save_and_overlay_gradcam saves as {original}_gradcam.jpg
            gradcam_full_path = save_and_overlay_gradcam(upload_path, heatmap)
            gradcam_filename = os.path.basename(gradcam_full_path)
            
            # Save DB
            conn = get_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO predictions (username, disease, confidence, timestamp, original_img, gradcam_img) VALUES (?, ?, ?, ?, ?, ?)",
                (current_user.username, disease, confidence, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), filename, gradcam_filename)
            )
            conn.commit()
            conn.close()
            
            return render_template('user/result.html', 
                                   disease=disease, 
                                   confidence=confidence, 
                                   severity=severity,
                                   desc=DESCRIPTIONS.get(disease, "No description available."),
                                   first_aid=FIRST_AID.get(disease, "Consult a dermatologist for specific advice."),
                                   original_img=filename,
                                   gradcam_img=gradcam_filename)

    return render_template('user/diagnose.html')

@main_bp.route('/history')
@login_required
def history():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM predictions WHERE username = ? ORDER BY id DESC", (current_user.username,))
    rows = cur.fetchall()
    conn.close()
    return render_template('user/history.html', history=rows)

@main_bp.route('/report/<filename>')
@login_required
def download_report(filename):
    # Re-generate PDF on the fly or serve if saved.
    # For simplicity, let's just implement a route that triggers PDF gen or serve existing.
    # The original app generated it on the fly. 
    # We can pass params to this route to regenerate? Or save it during diagnosis.
    # Saving during diagnosis is better.
    # For this iteration, I'll skip the PDF route implementation details and focus on the main flow.
    # If the user wants the PDF, we can add a button in result page that hits a generate endpoint.
    pass

@main_bp.route('/generate_pdf', methods=['POST'])
@login_required
def generate_pdf_route():
    # Receive data from form
    disease = request.form.get('disease')
    confidence = float(request.form.get('confidence'))
    severity = request.form.get('severity')
    original_img = request.form.get('original_img')
    gradcam_img = request.form.get('gradcam_img')
    
    # Paths
    base_path = os.path.join(current_app.root_path, 'static', 'uploads')
    orig_path = os.path.join(base_path, original_img)
    grad_path = os.path.join(base_path, gradcam_img)
    
    # Generate ID
    report_filename = f"report_{uuid.uuid4()}.pdf"
    
    # Generate Report
    try:
        generator = ReportGenerator(current_app.root_path)
        generator.generate(
            username=current_user.username,
            disease=disease,
            confidence=confidence,
            severity=severity,
            original_img_path=orig_path,
            gradcam_img_path=grad_path,
            output_filename=report_filename
        )
        
        report_dir = os.path.join(current_app.root_path, 'static', 'reports')
        if not os.path.exists(os.path.join(report_dir, report_filename)):
            flash('Error: Report generation failed (file not found).')
            return redirect(request.referrer or url_for('main.home'))
            
        return send_from_directory(report_dir, report_filename, as_attachment=True)
        
    except Exception as e:
        print(f"PDF Generation Error: {e}")
        flash('An error occurred while generating the report.')
        return redirect(request.referrer or url_for('main.home'))
